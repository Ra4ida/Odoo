{
    "name": "CRM custom",
    "version": "1.0",
    "summary": "CRM customization",
    "description": "CRM customization",
    "depends": ["base", "crm", "hms"],
    "data": [
        "views/partner_views.xml",
    ],
    "application": True,
    "installable": True,
    "auto_install": False,
}
